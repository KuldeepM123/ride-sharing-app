import images from './images';

export default images;
