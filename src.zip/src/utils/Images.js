const CustomImage = {
    mainLogo: require('../../assets/logo_f5buddy.webp'),
    menu: require('../../assets/menu.png'),
    noti: require('../../assets/noti.png'),
    close: require('../../assets/close.png'),
    pm: require('../../assets/pm.png'),
    dropdown: require('../../assets/dropdown.png'),
}
export { CustomImage }