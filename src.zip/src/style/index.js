import {StyleSheet} from 'react-native';
import {color} from 'react-native-reanimated';
import {Color} from '../utils/Colors';
import {fontSize, fontWeight} from '../utils/Font';
import {horizScale} from '../utils/Layout';

const gloableStyle = StyleSheet.create({});
export default gloableStyle;
